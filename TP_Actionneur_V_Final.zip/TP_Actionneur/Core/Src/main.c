/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cordic.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
//Constantes moteur
#define K 0.14
#define R 0.9
#define L 0.0005
#define J 0.002
#define F 0.037*60/(1000*2*pi)
#define GAMMAZ 0.2
#define CT L/R
#define CM J/F

#define UART_RX_BUFFER_SIZE 8
#define UART_TX_BUFFER_SIZE 8
#define CMD_BUFFER_SIZE 100

char uart_rx_buffer[UART_RX_BUFFER_SIZE];
char uart_tx_buffer[UART_TX_BUFFER_SIZE];

uint8_t byte;
uint8_t cmd[CMD_BUFFER_SIZE];
int idxCmd = 0;
const uint8_t help[] = "help" ;
const uint8_t pinout[] = "pinout";
const uint8_t power_on[] ="start" ;
const uint8_t power_off[] = "stop" ;
const uint8_t not_found[] =  "Command not found";
const uint8_t speed_c[] =  "speed";
const uint8_t speed_ask[] = "speed?";
uint8_t ASK_V = 0;
uint8_t new_value = 0;
uint8_t new_Cmd =0;
uint8_t ASK_S=0;

//uint16_t oldValue = 0;
uint32_t currentValue = 0;
uint16_t speed = 0;
uint16_t oldErreurV = 0;
uint16_t oldErreurI = 0;
uint16_t ErreurV = 0;
uint16_t ErreurI = 0;
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#include <stdio.h>
#include<string.h>
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

int __io_putchar(int ch) {
	HAL_UART_Transmit(&huart2, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
	return ch;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM1_Init();
  MX_CORDIC_Init();
  MX_TIM2_Init();
  MX_USART2_UART_Init();
  MX_TIM3_Init();
  MX_TIM7_Init();
  MX_TIM6_Init();
  MX_TIM16_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_1);
  HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_2);
  HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_2);
  HAL_TIM_Encoder_Start_IT(&htim3, TIM_CHANNEL_1);
  HAL_TIM_Encoder_Start_IT(&htim3, TIM_CHANNEL_2);
  HAL_TIM_Base_Start_IT(&htim7);
  HAL_TIM_Base_Start_IT(&htim6);
  HAL_TIM_Base_Start_IT(&htim16);

  HAL_UART_Receive_IT(&huart2, &byte, 1);
  //uint8_t condition_sortie = 0;
  uint8_t vit_demande =0;
  uint8_t i =0;

  //oldValue = TIM3->CNT;

  printf("\r\n============================================================================================\r\n");
  printf("Bonjour et bienvenue sur notre shell !!!\r\n");
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  currentValue = TIM3->CNT;
	  if(!strncmp("\r",&byte,1)){
		  if(!strncmp(&cmd[idxCmd-6],&power_on,5)){

			  	printf("\r\nPower ON\r\n");
	  			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
	  			HAL_Delay(1);
	  			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);

		  		byte = 'x';

		  }
		  else if(!strncmp(&cmd[idxCmd-7],&pinout,6)){
			  printf("\r\nPWM PINOUT :\r\n");
			  printf("\r\nPWM1->PC0\r\n");
			  printf("PWM1N->PA7\r\n");
			  printf("\r\nPWM2->PC1\r\n");
			  printf("PWM2N->PB0\r\n");
			  printf("\r\n\nGPIO :\r\n");
			  printf("\r\nReset->PA4\r\n");
			  printf("\r\n\nEncode :\r\n");
			  printf("\r\nEnc_A->PA6\r\n");
			  printf("Enc_B->PA7\r\n");

		  	    byte = 'x';

		  }
		  else if(!strncmp(&cmd[idxCmd-5],&power_off,4)){
		  	  	printf("\r\nPower OFF\r\n");
				vit_demande = 50;
				TIM1->CCR1 = (TIM1->ARR * vit_demande)/100;
				TIM1->CCR2 = TIM1->ARR - TIM1->CCR1;
				vit_demande = 0;
		  	    byte = 'x';

		  }
		  else if(!strncmp(&cmd[idxCmd-5],&help,4)){
		  		printf("\r\n-------------Help---------------\r\n");
		  		printf("follow the command below\r\n");
		  		printf("\r\npinout : display all pins to be connected\r\n");
		  		printf("start : start the motor\r\n");
		  		printf("stop : Stop the motor\r\n");
		  		printf("speed? : show what is the actual speed\r\n");
		  		printf("\r\nThe speed has to be asked in % with a value from 0 to 100, 50 set the speed to 0 RPM\r\n");
		  		printf("speed=xx\r\n\r\n");

		  		byte = 'x';//new_Cmd == 0;

		  }
		  else if(!strncmp(&cmd[idxCmd-7],&speed_ask,6)){
		  		  	ASK_S =1;
		  		  	byte = 'x';
		  }
		  else if(ASK_V==0){
			  printf("\r\nCommand not found\r\n");
			  byte = 0;
		  }
	  }

	  if(!strncmp("=",&byte,1) || ASK_V ==1){
		  if(!strncmp(&cmd[idxCmd-6],&speed_c,5) || ASK_V ==1 ){
			  ASK_V=1;
			  if(!strncmp(&byte,"\r",1))
			   {
			    ASK_V=0;
			    i=0;
			    printf("\r\nVitesse demandé : %d\r\n", vit_demande);
				if(vit_demande<=100){
					TIM1->CCR1 = (TIM1->ARR * vit_demande)/100;
					TIM1->CCR2 = TIM1->ARR - TIM1->CCR1;
			    }
				else{
					printf("\r\nSpeed has to be in 0 to 100\r\n");
				}
				vit_demande = 0;
			    byte='x';
			   }
			  else if(new_value==1){
				  //printf("new value");
				  vit_demande =  vit_demande*10 + atoi(&byte);
				  i++;
				  new_value=0;
			  }

		  }

	  }



	 //HAL_Delay(1000);
	 //printf("\r\nBonjour !!\r\n");
	 //HAL_UART_Transmit(&huart2,"O", 1, HAL_MAX_DELAY);

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV4;
  RCC_OscInitStruct.PLL.PLLN = 85;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the peripherals clocks
  */
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){

	if(huart->Instance == USART2 ){
		HAL_UART_Receive_IT(&huart2, &byte, 1);
		HAL_UART_Transmit(&huart2, &byte, 1, HAL_MAX_DELAY);
		new_value = 1;

		cmd[idxCmd] = byte;
		idxCmd++;
		//buffer[c] = &byte;
		//c++;

		/*
		if(!strncmp(byte,"!",1)){
			c=0;
		}

		if(c>5){
			c=0;
		}

		if(!strncmp(buffer,"Start",5) || c>=4){

		}
		*/
		//TIM1->CCR1 = ;
	}



}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
